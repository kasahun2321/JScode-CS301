let count1 = 1;
let count2 = 2;
console.log(count1);
console.log(++count1);
console.log(count2)
console.log(count2++);

let result = count1-- * 2 + 5;
console.log(result);
console.log(count1);