let x= 10;
let y = 5;

console.log(x>=10 && y<10) //true
console.log(x===10 || y===3) //true
console.log(x<99 && y>10) //false