let x = 5;
let y = "7";
let test = true;

let result = x+y;
console.log(result);
console.log(typeof result);

result = x+test;
console.log(result)
console.log(typeof result);

result = test+y
console.log(result);
console.log(typeof result)

result = y*2;
console.log(result);
console.log(typeof result)